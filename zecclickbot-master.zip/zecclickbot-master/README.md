# Link ZECClickBot Telegram
Hargai Refferal : https://t.me/Zcash_click_bot?start=YmCx

# Cara Install 
$ apt update && pkg upgrade<br>
$ apt install python git<br>
$ git clone https://github.com/kyo1337/zecclickbot<br>
$ cd zecclickbot<br>
$ pip3 install -r requirements.txt<br>
$ python3 main.py phone_number<br>

# Note :
- Bisa Menggunakan Nomor Luar/ID, Syarat Input Nomor : python main.py 62813****** / python main.py 1315*******
- Input OTP
- And Happy Mining

# Media Sosial :
- https://linktr.ee/doko1554

# Special Thx
 Jejaka Tutorial
